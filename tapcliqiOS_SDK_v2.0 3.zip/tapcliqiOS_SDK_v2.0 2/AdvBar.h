//
//  AdvBar.h
//  api
//
//  Created by Anant Patel on 1/13/11.
//  Copyright 2011 TransOut Inc. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <CoreLocation/CoreLocation.h>


@class AdvBar;

@protocol AdvBarProtocol <NSObject>

@optional

// Ad packet has been received and tapCLIQ ad view is about to be displayed
- (BOOL)presentT2RBar:(AdvBar*)bar;

// tapCLIQ ad view is about to be removed
- (void)removedT2RBar:(AdvBar*)bar;

// Ad is going to change
- (void)changeAd:(AdvBar *)bar;

/*  Implement fetchNewAdPacket (delegate method) and post a custom trigger in it , if you wish to fetch a new ad packet
e.g., 
 
 NSDictionary *dict = [[NSDictionary alloc] initWithObjects: [NSArray arrayWithObject:@"Coffee,Tea"] forKeys: [NSArray arrayWithObject:@"Tags"]];
[[NSNotificationCenter defaultCenter] postNotificationName: @"CustomTrigger" object: self userInfo: dict];
*/
- (void)fetchNewAdPacket:(AdvBar *)bar;

/* In order to support ads on a popover view implement below mentioned delegate method :
 - (UIPopoverController *)getViewControllerInchargeOfPopoverInPortarit {
 }
 
    wherein you should pass popover controller as shown in the e.g.below :
- (UIPopoverController *)getViewControllerInchargeOfPopoverInPortarit {
    return your_popovercontroller; 
 }
 */
- (UIPopoverController *)getViewControllerInchargeOfPopoverInPortarit;

// Notify your app of user's selection in a Question-Answer ad ( by passing a tag / link )
- (void)getUserSelection:(NSString *)data;

// Notified when their is an error with any tapCLIQ ad request
- (void)adError:(NSString *)description;

// Notified when fetched ad is about to be displayed
- (void)adAboutToDisplay:(AdvBar *)adView;

@end

@interface AdvBar : UIView <CLLocationManagerDelegate> {

    //__unsafe_unretained
  //  id <AdvBarProtocol> __weak *mydelegate;
   

}

@property (weak) id <AdvBarProtocol> mydelegate;
@property (nonatomic, readonly) int orientation; 
@property (unsafe_unretained, nonatomic, readonly) int questionId, answer, placeCampaignID;
@property (unsafe_unretained, nonatomic, readwrite) int dealId,placeId;



@property (weak) UIViewController *calledBy;
@property  (unsafe_unretained, nonatomic, readonly) bool  isConnectionError, isRunning, isHidingEnabled, isEventCheckin, isSubEventCheckin;
@property (unsafe_unretained, nonatomic, readonly) int errorCode, cfaIdentifier,displayTime;
@property (unsafe_unretained, nonatomic, readonly) float timeOutValue, myWidth ,myHeight;
@property (weak, nonatomic, readonly) NSString *chkinPlaceName, *chkinAdvUrl;


@property (weak) NSTimer *timeOutForQuestion;
           

// Should be called from app delegate as mentioned in the integration doc tqSetUp & tqCleanUp help in getting app session data
+ (void)tqSetUp;
/*
// Call this tqSetUp Method if you want to you app even tracking along with app session data
+ (void)tqSetUp:(NSString *)applicationId;
*/
// Should be called when app goes into the background / terminated
+ (void)tqCleanUp;

//Should be called to register device token for push notification
+ (void)setPushDeviceToken:(NSData *)devToken forAppId:(NSString *)myAppId;

// Handle received push notification
+ (void)handlePushNotification:(NSDictionary *)pushedData;

// Record an event (Event may be a user action or a screen or anything you wish to track in your app
+ (void)tagEvent:(NSString *)eventName  eventAttributes:(NSDictionary *)attributes;


- (void)recordMoment:(NSString *)momentName  momentAttributes:(NSDictionary *)attributes;
/*  Initialize tapcliq ad view - where appId (Id assigned to this app on registration), origin (x,y coordinates where ad view should start), caller (parent View Controller in which ad view is integrated),  adType (based on type a) Small_Ad  b) Square_Ad c) FullScreen_Ad d) 1024x90 e) 700x90) , adUnitId (Ad unit Id given on registration of this ad view - helps in targeting if ad views are registered based on app screens)
 */



-(id) initWithAppId:(NSString *)appId origin:(CGPoint)origin from:(UIViewController*)caller adType:(NSString *)type adUnitId:(int)unitId;

// Initialize tapcliq ad view without ad unit Id
-(id) initWithAppId:(NSString *)appId origin:(CGPoint)origin from:(UIViewController*)caller adType:(NSString *)type;

//Initialize web ad view
-(id) initWithAppId:(NSString *)appId origin:(CGPoint)origin from:(UIViewController*)caller webadType:(NSString *)type adUnitId:(int)unitId tag:(NSString *)myAdTag;
// Method to handle orientation changes 
- (void)adOrientationChanged:(int)interfaceOrientation xAxis:(float)x yAxis:(float)y adType:(NSString *)type;

// Method for button that pops-up tapCLIQ custom view ( for rewards / Login etc. )
// parentViewController - View controller in which tQ button is integrated
- (void)tqWebView:(UIViewController *)parentViewController;




/*

 e.g., ad view intialization in viewDidAppear
 if(ab == nil) {
 if (UI_USER_INTERFACE_IDIOM() == UIUserInterfaceIdiomPhone) {
 
 ab = [[AdvBar alloc] initWithAppId:@"bf29df4703374e0ebac9169922849a94" origin:CGPointMake(0.0,480.0 - 70.0) from:self adType:@"Small_Ad"];
 
 ab.tag = 191;
 ab.mydelegate = self;
 [self.view addSubview:ab];
 
 }
 // fetch ads
 [self fetchNewAdPacket:ab];
 
 
 }
*/
@end


