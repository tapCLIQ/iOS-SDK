//
//  sampleViewController.h
//  pushtesttq
//
//  Created by Anant  Patel on 10/3/13.
//  Copyright (c) 2013 tapcliq. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface sampleViewController : UIViewController

@end
