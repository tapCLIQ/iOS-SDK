//
//  main.m
//  pushtesttq
//
//  Created by Anant  Patel on 10/3/13.
//  Copyright (c) 2013 tapcliq. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "sampleAppDelegate.h"

int main(int argc, char * argv[])
{
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([sampleAppDelegate class]));
    }
}
