//
//  sampleViewController.m
//  pushtesttq
//
//  Created by Anant  Patel on 10/3/13.
//  Copyright (c) 2013 tapcliq. All rights reserved.
//

#import "sampleViewController.h"
#import <QuartzCore/QuartzCore.h>

@interface sampleViewController ()

@end

@implementation sampleViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view, typically from a nib.
    
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
