//
//  sampleViewController.h
//  tQSDKSample
//
//  Created by Anant  Patel on 8/19/13.
//  Copyright (c) 2013 Anant. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AdvBar.h"
@interface sampleViewController : UIViewController <AdvBarProtocol> {
    
    AdvBar *adView;
}

@end
