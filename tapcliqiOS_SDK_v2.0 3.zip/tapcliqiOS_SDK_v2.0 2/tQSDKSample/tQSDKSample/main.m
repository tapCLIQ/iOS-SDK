//
//  main.m
//  tQSDKSample
//
//  Created by Anant  Patel on 8/19/13.
//  Copyright (c) 2013 Anant. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "sampleAppDelegate.h"

int main(int argc, char *argv[])
{
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([sampleAppDelegate class]));
    }
}
