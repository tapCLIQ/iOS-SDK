//
//  sampleViewController.m
//  tQSDKSample
//
//  Created by Anant  Patel on 8/19/13.
//  Copyright (c) 2013 Anant. All rights reserved.
//

#import "sampleViewController.h"


@interface sampleViewController ()


@end

@implementation sampleViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view, typically from a nib.
}


- (BOOL)shouldAutorotate {
    return YES;
}

- (NSUInteger)supportedInterfaceOrientations {
    
    return UIInterfaceOrientationMaskPortrait | UIInterfaceOrientationMaskLandscape;
}


-(void) PostAdTrigger:(NSString *)tags
{
    
 
    NSDictionary *dict = [[NSDictionary alloc] initWithObjects:[NSArray arrayWithObject:tags] forKeys:[NSArray arrayWithObject:@"Tags"]];
    [[NSNotificationCenter defaultCenter] postNotificationName:@"CustomTrigger" object:self userInfo:dict];
}


- (void)viewDidAppear:(BOOL)animated {
    
    if ( adView == nil) {
        
        adView = [[AdvBar alloc] initWithAppId:@"ac609f5c84444ce1bf67e293b4c04c59" origin:CGPointMake(self.view.frame.origin.x, self.view.frame.size.height - 50.0) from:self adType:@"Small_Ad" adUnitId:1]; // Based on the type of ad view you wish to integrate adType can be @"Square_Ad" or @"FullScreen_Ad" or @"700x90" (Detail View of a SplitViewController) or @"1024x90" (Full Width) or @"Small_Ad" (for a 320x50 ad)
        adView.tag =131313;
        adView.mydelegate = self;
        [self.view addSubview:adView];
       
          }

    // Call PostAdTrigger with your tag(s) to fetch ads after the ad view is initialized
    [self PostAdTrigger:@"sports,home"];
    
    
 
}




- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void)dealloc {
 
    
    adView.timeOutForQuestion = nil;
    adView.calledBy = nil;
    adView = nil;
    
}


// implement this method with your tags to continue fetching ads (after one ad packet is done displaying)
- (void)fetchNewAdPacket:(AdvBar *)bar {
 
    NSDictionary *dict = [[NSDictionary alloc] initWithObjects: [NSArray arrayWithObject:@"home,sports"] forKeys: [NSArray arrayWithObject:@"Tags"]];
    [[NSNotificationCenter defaultCenter] postNotificationName: @"CustomTrigger" object: self userInfo: dict];
 
}

- (void)didRotateFromInterfaceOrientation: (UIInterfaceOrientation)fromInterfaceOrientation {
   
    if(UIInterfaceOrientationIsPortrait([[UIDevice currentDevice] orientation])) {
        [((AdvBar*) [self.view viewWithTag:131313]) adOrientationChanged:[[UIDevice currentDevice] orientation]
                                                              xAxis:0.0 yAxis:self.view.frame.size.height - 50.0 adType:@"Small_Ad"];
    }
    else {
        [((AdvBar*) [self.view viewWithTag:131313]) adOrientationChanged:[[UIDevice currentDevice] orientation] xAxis:80.0 yAxis:self.view.frame.size.height - 40.0 adType:@"Small_Ad"];
    }
 }

@end
