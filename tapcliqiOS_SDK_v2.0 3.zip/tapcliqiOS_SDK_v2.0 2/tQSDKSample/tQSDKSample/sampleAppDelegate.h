//
//  sampleAppDelegate.h
//  tQSDKSample
//
//  Created by Anant  Patel on 8/19/13.
//  Copyright (c) 2013 Anant. All rights reserved.
//

#import <UIKit/UIKit.h>

@class sampleViewController;

@interface sampleAppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@property (strong, nonatomic) sampleViewController *viewController;

@end
