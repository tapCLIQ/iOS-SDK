//
//  ViewController.h
//  BeaconReceiver
//
//  Created by Anant  Patel on 7/14/14.
//  Copyright (c) 2014 anant. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <CoreLocation/CoreLocation.h>


@protocol MonitorTQProximityDelegate <NSObject>

-(void)userEnteredRegion: (NSString *)regionIdentifier;
-(void)userExitedRegion: (NSString *)regionIdentifier;
-(void)beaconFound:(CLBeacon *)beacon beaconProximity:(NSString *)proximity data:(NSDictionary *)extraData;

@end

@interface TQBeaconManager : NSObject <CLLocationManagerDelegate> {
    
    id <MonitorTQProximityDelegate> __weak delegate;
}

@property (weak) id <MonitorTQProximityDelegate> delegate;
+ (TQBeaconManager *)sharedTQBeaconManager;
- (id)startMonitoringBeaconsForAppId:(NSString *)myAppId;

@end

